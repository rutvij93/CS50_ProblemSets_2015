/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <cs50.h>
#include "dictionary.h"

bool check(const char* word);

bool unload(void);

bool load(const char* dictionary);
node* first;
node* new1;
int wordcount = 0;

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    int i = 0, k = 0;
    node* temp = first;
    const char* word1 = word;
    for(i = 0; i < strlen(word1); i++)
    {
        if (tolower(word1[i]) == '\'')
        {
            k = 26;
        }
        else
        {
            k = (tolower(word1[i]) - 'a');
        }
        if (temp->next_char[k] == NULL)
        {
            break;
        }
        else
        {
            temp = temp->next_char[k];
        }
    }
    if ((temp->wordpresent == true) && (i == strlen(word1)))
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    new1 = calloc(2000000, sizeof(node));
    node* new = new1;
    first = malloc(sizeof(node));
    for(int j = 0;j <= 26; ++j)
    {
        first->next_char[j] = NULL;
    }
    char word[LENGTH + 1];
    int index = 0;
    FILE* fp = fopen(dictionary, "r");
    for (int c = fgetc(fp); c != EOF; c = fgetc(fp)) 
    {
        if (isalpha(c) || (c == '\'' && index > 0))
        {
            word[index] = c;
            index++;
        }
        else if (index > 0)
        {
            int k = 0;
            word[index] = '\0';
            index = 0;
            wordcount++;
            node* temp = first;
            for(int i = 0; i < strlen(word); i++)
            {
                if (word[i] == '\'')
                {
                    k = 26;
                }
                else
                {
                    k = (word[i] - 'a');
                }
                if (temp->next_char[k] == NULL)
                {
                    for(int j = 0;j <= 26; ++j)
                    {
                        new->next_char[j] = NULL;
                    }
                    temp->next_char[k] = new;
                    temp = new;
                    if (i == (strlen(word) - 1))
                    {
                        new->wordpresent = true;
                    }
                    new++;
                }
                else
                {
                    temp = temp->next_char[k];
                    if ((temp->next_char[k] == NULL) && (i == strlen(word)))
                    {
                        temp->wordpresent = true;
                    }
                }
            }
        }
    }
    fclose(fp);
    return true;
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    return wordcount;
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    free(new1);
    return true;
}
