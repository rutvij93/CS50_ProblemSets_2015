/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */
#include <stdio.h> 
#include <stdlib.h> 
#include <stdint.h> 
#include <string.h> 

int main(void)
{
    // to check error during input ptr assignment
    FILE *inptr = fopen("card.raw", "r");
    if (inptr == NULL)
    {
        fclose(inptr);
        printf("Error in opening card.raw");
        return 0;
    }
    // Sequence to find jpeg image
    //uint8_t jpg1[4] = {0xff, 0xd8, 0xff, 0xe0};
    //uint8_t jpg2[4] = {0xff, 0xd8, 0xff, 0xe1};
    // block size
    // Output file name
    int opname = -1;
    FILE *outptr;
    uint8_t block[512];
    // Check for end of file
    while(!(feof(inptr)))
    {
        // JPEG image header check
        fread(block, 512, 1, inptr);
        if(block[0] == 0xff && block[1] == 0xd8 && block[2] == 0xff && (block[3] == 0xe0 || block[3] == 0xe1)) 
        {
            opname = opname + 1;
            // construct file name
            char opnamefinal[8]; 
		    sprintf(opnamefinal, "%03d.jpg", opname);
		    // Need not close file as it is not opened yet
            if (opname == 0)
            {
                outptr = fopen(opnamefinal, "w"); 
				fwrite(block, sizeof(block), 1, outptr);
            }
            else
            {
                fclose(outptr);
                outptr = fopen(opnamefinal, "w"); 
				fwrite(block, sizeof(block), 1, outptr);
            }
        }
        else 
		{ 
			if(opname >= 0) 
			{ 
					fwrite(block, sizeof(block), 1, outptr); 
			} 
		} 
    } 
    // close all the files
    if(outptr) 
    { 
        fclose(outptr); 
    }
    fclose(inptr); 
    return 0;     
}
